#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_MPU6050.h>
#include "button.h"

#define LED_PIN 2
#define BUZZER_PIN 15
#define POT_PIN 34

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
Adafruit_MPU6050 mpu;

int heartRate = 70;
float temp = 25.0;

enum DisplayMode { MODE_CLOCK, MODE_HEART, MODE_NOTIF };
DisplayMode currentMode = MODE_CLOCK;

struct Time { int h, m, s; };
Time clockTime = {12, 0, 0};
unsigned long lastClockUpdate = 0;

unsigned long lastHRUpdate = 0;
unsigned long lastTempUpdate = 0;

String motivationalMsgs[15] = {
  "Keep going!", "You can do it!", "Don't give up!",
  "Great progress!", "Stay strong!", "Push your limits!",
  "Believe in yourself!", "Never stop!", "Stay motivated!",
  "You got this!", "Almost there!", "Keep pushing!",
  "Stay focused!", "You're amazing!", "One more time!"
};

int motivIndex = -1;
int notifIndex = 0;

Time alarmTime = {12, 1, 0};
bool alarmTriggered = false;
bool hourlyAlarmTriggered = false;
int lastHourAlerted = -1;
bool heartAlertActive = false;
unsigned long lastHeartAlert = 0;
const unsigned long heartAlertInterval = 3000;

unsigned long lastButtonCheck = 0;
const int buttonCheckInterval = 20;

int potValue = 0;
unsigned long lastPotRead = 0;
const int potReadInterval = 100;

unsigned long lastMotionCheck = 0;
const int motionCheckInterval = 500;
bool motionDetected = false;

void setup() {
  Serial.begin(115200);
  buttons_init();

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(21, 22);

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3D)) {
      while(1);
    }
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(2);
  display.setCursor(10, 20);
  display.print("SMART WATCH");
  display.display();
  delay(1500);

  pinMode(POT_PIN, INPUT);

  if (mpu.begin()) {
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }
}

void updateClock() {
  if (millis() - lastClockUpdate >= 1000) {
    lastClockUpdate = millis();
    clockTime.s++;
    if(clockTime.s >= 60) { clockTime.s = 0; clockTime.m++; }
    if(clockTime.m >= 60) { clockTime.m = 0; clockTime.h++; }
    if(clockTime.h >= 24) { clockTime.h = 0; }
  }
}

void readPotentiometer() {
  if (millis() - lastPotRead >= potReadInterval) {
    lastPotRead = millis();
    potValue = analogRead(POT_PIN);
  }
}

void updateHeartRate() {
  if (millis() - lastHRUpdate >= 1000) {
    lastHRUpdate = millis();
    heartRate = map(potValue, 400, 4095, 0, 170);
    if (heartRate < 0) heartRate = 0;
    if (heartRate > 170) heartRate = 170;
  }
}

void updateTemperature() {
  if (millis() - lastTempUpdate >= 2000) {
    lastTempUpdate = millis();
    temp = 20.0 + (potValue / 4095.0 * 20.0);
  }
}

void checkHeartRateAlert() {
  if (heartRate > 100) {
    if (!heartAlertActive) {
      heartAlertActive = true;
      lastHeartAlert = millis();
      tone(BUZZER_PIN, 1500, 500);
    }
    if (millis() - lastHeartAlert >= heartAlertInterval) {
      lastHeartAlert = millis();
      tone(BUZZER_PIN, 1500, 300);
    }
  }
  else if (heartRate < 60) {
    if (!heartAlertActive) {
      heartAlertActive = true;
      lastHeartAlert = millis();
      tone(BUZZER_PIN, 700, 500);
    }
    if (millis() - lastHeartAlert >= heartAlertInterval) {
      lastHeartAlert = millis();
      tone(BUZZER_PIN, 700, 300);
    }
  }
  else {
    heartAlertActive = false;
    noTone(BUZZER_PIN);
  }
}

void checkHourlyAlarm() {
  if (clockTime.m == 0 && clockTime.s == 0) {
    if (!hourlyAlarmTriggered || lastHourAlerted != clockTime.h) {
      hourlyAlarmTriggered = true;
      lastHourAlerted = clockTime.h;
      tone(BUZZER_PIN, 1000, 200);
    }
  } else {
    hourlyAlarmTriggered = false;
  }
}

void checkMotion() {
  if (millis() - lastMotionCheck >= motionCheckInterval) {
    lastMotionCheck = millis();

    sensors_event_t a, g, tempSensor;
    mpu.getEvent(&a, &g, &tempSensor);

    float acceleration = sqrt(
      a.acceleration.x * a.acceleration.x +
      a.acceleration.y * a.acceleration.y +
      a.acceleration.z * a.acceleration.z
    );

    motionDetected = acceleration > 15.0;
  }
}

void drawRunner() {
  display.fillCircle(110, 28, 4, SSD1306_WHITE);
  display.drawLine(110, 32, 110, 44, SSD1306_WHITE);
  display.drawLine(110, 34, 120, 38, SSD1306_WHITE);
  display.drawLine(110, 34, 100, 38, SSD1306_WHITE);
  display.drawLine(110, 44, 118, 52, SSD1306_WHITE);
  display.drawLine(110, 44, 102, 52, SSD1306_WHITE);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);

  updateClock();
  readPotentiometer();
  updateHeartRate();
  updateTemperature();
  checkMotion();
  checkHeartRateAlert();
  checkHourlyAlarm();

  if (millis() - lastButtonCheck >= buttonCheckInterval) {
    lastButtonCheck = millis();

    if (read_button_clock()) currentMode = MODE_CLOCK;
    if (read_button_hr()) currentMode = MODE_HEART;
    if (read_button_notif()) {
      currentMode = MODE_NOTIF;
      notifIndex = (notifIndex + 1) % 3;
      motivIndex = (motivIndex + 1) % 15;
    }
  }

  if (!alarmTriggered &&
      clockTime.h == alarmTime.h &&
      clockTime.m == alarmTime.m) {
    alarmTriggered = true;
    tone(BUZZER_PIN, 1200, 1000);
  }

  display.clearDisplay();
  display.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, SSD1306_WHITE);

  if (currentMode == MODE_CLOCK) {
    display.setTextSize(2);
    display.setCursor(4, 4);
    if (clockTime.h < 10) display.print('0');
    display.print(clockTime.h);
    display.print(':');
    if (clockTime.m < 10) display.print('0');
    display.print(clockTime.m);
    display.print(':');
    if (clockTime.s < 10) display.print('0');
    display.println(clockTime.s);

    display.setTextSize(1);
    display.setCursor(4, 34);
    display.print("Temp: ");
    display.print(temp, 1);
    display.println("C");

    display.setCursor(4, 49);
    display.print("HR: ");
    display.print(heartRate);
    display.println(" BPM");
  }

  else if (currentMode == MODE_HEART) {
    display.setTextSize(2);
    display.setCursor(4, 4);
    display.print("HEART RATE");

    display.setTextSize(3);
    display.setCursor(4, 34);
    display.print(heartRate);
    display.print(" BPM");

    if (heartRate < 60) {
      display.setTextSize(1);
      display.setCursor(4, 58);
      display.print("WARNING: Below 60 BPM");
    }
  }

  else if (currentMode == MODE_NOTIF) {
    display.setTextSize(2);
    display.setCursor(4, 4);
    display.print("NOTIFY");

    display.setTextSize(2);
    display.setCursor(4, 26);

    if (notifIndex == 1) {
      display.print(motivationalMsgs[motivIndex]);
    }
    else if (notifIndex == 2) {
      display.print("Exercise ");
      drawRunner();
    }
  }

  display.display();
}
