#include "time_module.h"
#include <Arduino.h>

void time_update(Time* t) {
    t->hours = (millis() / 3600000) % 24;
    t->minutes = (millis() / 60000) % 60;
}
