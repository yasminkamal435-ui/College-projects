#ifndef TIME_MODULE_H
#define TIME_MODULE_H

typedef struct {
    int hours;
    int minutes;
    int seconds;
} Time;

void time_init(Time *t, int h, int m, int s);


void time_update(Time *t);

void time_print(Time *t);

#endif

