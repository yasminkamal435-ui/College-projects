#ifndef SENSOR_H
#define SENSOR_H

int read_heart_rate();
float read_temperature();

#endif
