#ifndef NOTIFICATION_H
#define NOTIFICATION_H

void notification_init();       
void send_notification(char*); 

#endif
