#include <Arduino.h>
#include "button.h"

void buttons_init() {
    pinMode(BTN_CLOCK, INPUT_PULLUP);
    pinMode(BTN_HR, INPUT_PULLUP);
    pinMode(BTN_NOTIF, INPUT_PULLUP);
}

int read_button_clock() {
    return digitalRead(BTN_CLOCK) == LOW;
}

int read_button_hr() {
    return digitalRead(BTN_HR) == LOW;
}

int read_button_notif() {
    return digitalRead(BTN_NOTIF) == LOW;
}
