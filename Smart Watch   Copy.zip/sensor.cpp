#include "sensor.h"
#include <Arduino.h>

int read_heart_rate() {
    return random(60, 100);
}

float read_temperature() {
    return random(36, 38);
}
