#include "system_init.h"
#include <Arduino.h>

void system_init() {
}
