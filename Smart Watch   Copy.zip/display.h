#ifndef DISPLAY_H
#define DISPLAY_H
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display; 

void display_time(int h, int m, int s);
void display_notifications_page(const char* msg);
void display_health_page(int lastHeartRate, bool isMeasuring);

#endif