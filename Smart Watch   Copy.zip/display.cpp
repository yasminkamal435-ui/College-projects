#include "display.h"
#include <Adafruit_SSD1306.h>
#include <Wire.h>

extern Adafruit_SSD1306 display;

void display_time(int h, int m, int s) {
    display.clearDisplay();
    
    display.drawRect(0, 0, 128, 64, WHITE);
    
    display.setCursor(35, 5);
    display.setTextSize(1);
    display.println("MY WATCH");

    display.setCursor(15, 25);
    display.setTextSize(2);
    if (h < 10) display.print("0");
    display.print(h);
    display.print(":");
    if (m < 10) display.print("0");
    display.print(m);
    display.print(":");
    if (s < 10) display.print("0");
    display.print(s);

    display.setCursor(10, 50);
    display.setTextSize(1);
    display.print("BTN1: Mode ->");
    
    display.display();
}

void display_notifications_page(const char* msg) {
    display.clearDisplay();
    display.setTextSize(1);
    
    display.setCursor(0,0);
    display.println("--- NOTIFICATIONS ---");
    display.drawLine(0, 10, 128, 10, WHITE);

    display.setCursor(0, 20);
    display.setTextSize(1);
    display.println(msg); 

    display.display();
}

void display_health_page(int lastHeartRate, bool isMeasuring) {
    display.clearDisplay();
    display.setTextSize(1);
    
    display.setCursor(30, 0);
    display.println("HEALTH HUB");
    display.drawLine(0, 10, 128, 10, WHITE);

    if (isMeasuring) {
        display.setCursor(20, 25);
        display.setTextSize(2);
        display.println("Reading..");
        display.setTextSize(1);
        display.setCursor(10, 50);
        display.println("Please wait...");
    } else {
        display.setCursor(0, 20);
        display.setTextSize(1);
        display.print("Last BPM: ");
        display.setTextSize(2);
        display.println(lastHeartRate);
        display.setTextSize(1);
        display.setCursor(0, 50);
        display.println("[BTN2] to Measure");
    }
    display.display();
}