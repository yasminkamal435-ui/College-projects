#ifndef BUTTON_H
#define BUTTON_H

#define BTN_CLOCK 12
#define BTN_HR 13
#define BTN_NOTIF 14

void buttons_init();
int read_button_clock();
int read_button_hr();
int read_button_notif();

#endif
