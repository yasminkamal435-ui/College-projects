#include "notification.h"
#include <Arduino.h>

void notification_init() {
    // Initial setup for notification system
    Serial.println("Notification system initialized");
}

void send_notification(char* msg) {
    // Simulated notification sender
    Serial.print("Notification sent: ");
    Serial.println(msg);
}
